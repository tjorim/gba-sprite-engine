//
// Created by ubuntu on 29.11.18.
//

#ifndef GBA_SPRITE_ENGINE_PROJECT_BETTERSCENE_H
#define GBA_SPRITE_ENGINE_PROJECT_BETTERSCENE_H

#include <libgba-sprite-engine/scene.h>
#include <libgba-sprite-engine/gba_engine.h>

class BetterScene  : public Scene  {
private:
    std::unique_ptr<Sprite> mooi_sprite;
    std::unique_ptr<Sprite> mooi_sprite1;
    std::unique_ptr<Sprite> eendje;
    std::unique_ptr<Background> bg;

public:
    BetterScene(std::shared_ptr<GBAEngine> engine) : Scene(engine) {}

    std::vector<Sprite *> sprites() override;
    std::vector<Background *> backgrounds() override;

    void load() override;
    void tick(u16 keys) override;

    int player1TranslationH = 100;
    int player1TranslationV = 145;
    int player2TranslationH = 150;
    int player2TranslationV = 145;
    int currentPlayer = 0;
    int counter=0;


};


#endif //GBA_SPRITE_ENGINE_PROJECT_BETTERSCENE_H
