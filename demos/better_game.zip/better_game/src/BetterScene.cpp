//
// Created by ubuntu on 29.11.18.
//

#include "BetterScene.h"
//#include "castleworker.h"
#include "background.h"
#include <libgba-sprite-engine/sprites/sprite_builder.h>
#include <libgba-sprite-engine/gba_engine.h>
#include <algorithm>
#include <libgba-sprite-engine/background/text_stream.h>
#include <sstream>

#define PLAYER_TRANSLATION_DIFF 1
#define PLAYER_UPDOWN 1

std::vector<Sprite *> BetterScene::sprites() {
    return{
        mooi_sprite.get(), mooi_sprite1.get()  , eendje.get()
    };
}
std::vector<Background *> BetterScene::backgrounds() {
    return{
        bg.get()
    };
}
void BetterScene::load() {
    foregroundPalette = std::unique_ptr<ForegroundPaletteManager>(new ForegroundPaletteManager(sharedPal, sizeof(sharedPal)));
    backgroundPalette = std::unique_ptr<BackgroundPaletteManager>(new BackgroundPaletteManager(bg_palette, sizeof(bg_palette)));

    SpriteBuilder<Sprite> builder;

    mooi_sprite = builder
            .withData(CastleWorkerGrijsTiles, sizeof(CastleWorkerGrijsTiles))
            .withSize(SIZE_16_16)
            .withLocation(100,145)
            .buildPtr();

    mooi_sprite1 = builder
            .withData(CastleWorkerGrijsTiles, sizeof(CastleWorkerGrijsTiles))
            .withSize(SIZE_16_16)
            .withLocation(150,145 )
            .buildPtr();

    eendje = builder
            .withData(DuckyGrijsTiles, sizeof(DuckyGrijsTiles))
            .withSize(SIZE_16_16)
            .withLocation(200, 135)
            .buildPtr();

        bg = std::unique_ptr<Background>(new Background(1, background_data, sizeof(background_data), map, sizeof(map)));
        bg.get()->useMapScreenBlock(14);
}
void BetterScene::tick(u16 keys) {
    if (engine->getTimer()->getTotalMsecs() < 5000) {
        counter++;
    } else {
        engine->getTimer()->stop();
    }

    mooi_sprite->animateToFrame(0);
    mooi_sprite1->animateToFrame(0);
    eendje->flipHorizontally(true);
    eendje->animateToFrame(0);

    if(keys & KEY_L){
        currentPlayer = currentPlayer+1;
    }
    if(currentPlayer >= 2){
        currentPlayer = 0;
    }
    //mooi_sprite.get()->moveTo(mooi_sprite.get()->getX(),mooi_sprite->getY()+1);
    if(currentPlayer == 0) {
        if (keys & KEY_LEFT) {
            mooi_sprite->flipHorizontally(false);
            player1TranslationH -= PLAYER_TRANSLATION_DIFF;
        } else if (keys & KEY_RIGHT) {
            mooi_sprite->flipHorizontally(true);
            player1TranslationH += PLAYER_TRANSLATION_DIFF;
        } else if (keys & KEY_UP) {
            player1TranslationV -= PLAYER_UPDOWN;
        } else if (keys & KEY_DOWN) {
            player1TranslationV += PLAYER_UPDOWN;
        } else if (keys & KEY_B) {
            //if in de buurt van de ladder
            //de ladder op
        }

        mooi_sprite->moveTo(player1TranslationH, player1TranslationV);

    }
        else if (currentPlayer == 1) {
            if (keys & KEY_LEFT) {
                mooi_sprite1->flipHorizontally(false);
                player2TranslationH -= PLAYER_TRANSLATION_DIFF;
            } else if (keys & KEY_RIGHT) {
                mooi_sprite1->flipHorizontally(true);
                player2TranslationH += PLAYER_TRANSLATION_DIFF;
            } else if (keys & KEY_UP) {
                player2TranslationV -= PLAYER_UPDOWN;
            } else if (keys & KEY_DOWN) {
                player2TranslationV += PLAYER_UPDOWN;
            } else if (keys & KEY_FIRE) {
                //if in de buurt van de ladder
                //de ladder op
            }


            mooi_sprite1->moveTo(player2TranslationH, player2TranslationV);

        }


    }
